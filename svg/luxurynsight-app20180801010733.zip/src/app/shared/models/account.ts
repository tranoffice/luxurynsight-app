export class Account {
    email: string;
    firstname: string;
    lastname: string;
    session: string;
}
